
class bca 
{
    String subject = "Programming with Java";
    bca ()
    {

    }
    
    void showData()
    {
        System.out.println("Subject: " + subject);
    }
}
public class DefSub {
    public static void main(String[] args) {
        bca s1 = new bca();
        s1.showData();
    }
}
