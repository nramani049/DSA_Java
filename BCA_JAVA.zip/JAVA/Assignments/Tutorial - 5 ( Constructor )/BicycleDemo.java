import java.util.Scanner;

class Bicycle {
    String type;
    double price;
    int year;

    // Default constructor
    Bicycle() {

    }

    // Parameterized constructor
    Bicycle(String t, double p, int y) {
        type = t;
        price = p;
        year = y;
    }

    // Method to take input from the user
    void input() {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter Bicycle Type: ");
        type = sc.nextLine();

        System.out.print("Enter Bicycle Price: ");
        price = sc.nextDouble();

        System.out.print("Enter Year of Manufacture: ");
        year = sc.nextInt();
    }

    // Method to display the bicycle details
    void display() {
        System.out.println("Bicycle Type: " + type);
        System.out.println("Bicycle Price: " + price);
        System.out.println("Year of Manufacture: " + year);
    }
}

public class BicycleDemo {
    public static void main(String[] args) {
        // Using default constructor
        Bicycle bicycle1 = new Bicycle();
        System.out.println("Bicycle 1 Details (Default Constructor):");
        bicycle1.display();

        System.out.println();

        // Using parameterized constructor
        Bicycle bicycle2 = new Bicycle("Mountain Bike", 15000, 2023);
        System.out.println("Bicycle 2 Details (Parameterized Constructor):");
        bicycle2.display();

        System.out.println();

        // Using input method to take user input
        Bicycle bicycle3 = new Bicycle();
        System.out.println("Enter details for Bicycle 3:");
        bicycle3.input();
        System.out.println("Bicycle 3 Details (User Input):");
        bicycle3.display();
    }
}
