class FactSer {
    // Parameterized constructor
    FactSer(int n) {
        System.out.println("Factorial Series for numbers up to " + n + ":");
        
        for (int i = 1; i <= n; i++) {
            System.out.println(i + "! = " + factorial(i));
        }
    }
    
    // Method to calculate factorial of a number
    int factorial(int num) {
        int fact = 1;
        
        for (int i = 1; i <= num; i++) {
            fact *= i;
        }
        
        return fact;
    }
}

public class Factorial {
    public static void main(String[] args) {
        // Creating an object and passing number to the constructor
        FactSer fs = new FactSer(5);  // Example number
    }
}
