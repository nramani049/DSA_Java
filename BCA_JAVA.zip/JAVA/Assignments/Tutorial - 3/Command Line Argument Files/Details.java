public class Details {
    public static void main(String[] rn) {
        int r=Integer.parseInt(rn[0]);
        String nm = rn[1];

		System.out.println("Roll No :"+r);
		System.out.print("Name ="+nm);	
    }
}
