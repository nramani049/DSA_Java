public class numPatt {
    public static void main(String[] patt) {
    
        // Prompt the user to enter a value
        int val = Integer.parseInt(patt[0]);

        // Print the multiplication table pattern
        for (int i = 1; i <= 10; i++) {
            System.out.println(val + " * " + i + " = " + (val*i));
        }
    }
}
