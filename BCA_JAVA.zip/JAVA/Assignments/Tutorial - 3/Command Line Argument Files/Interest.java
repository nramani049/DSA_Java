public class Interest {
    public static void main(String[] si) {
        int amt=Integer.parseInt(si[0]);
        int r=Integer.parseInt(si[1]);
        int t=Integer.parseInt(si[2]);

        int sit=(amt * r * t)/100;

        System.out.println("Principle amount: "+amt);
        System.out.println("Rate of interest: "+r);
        System.out.println("Time period: "+t);
        System.out.println("Simple Interest: "+sit);
    }
}
