public class starPatt {
    public static void main(String[] patt) {
        int l=Integer.parseInt(patt[0]);

        for(int i=0;i<l;i++){
            for(int j=0;j<=i;j++){
                System.out.print("* ");
            }
            System.out.println();
        }
        for(int i=l-2;i>=0;i--){
            for(int j=0;j<=i;j++){
                System.out.print("* ");
            }
            System.out.println();
        }
    }
}
