public class Leap {

    public static void main(String year[])
	{
		int num=Integer.parseInt(year[0]);
        			
        if(num%4==0)
	    {    
	        System.out.println("Leap");
        }
        else
        {
                System.out.println("Not Leap");
	    }
                
        
	}
    
}