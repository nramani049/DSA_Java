public class oddeven {
    
    public static void main(String oe[])
	{
		int num=Integer.parseInt(oe[0]);
        			
        if(num%2==0)
	    {    
	        System.out.println(num + " is odd.");
        }
        else
        {
                System.out.println(num + " is even.");
	    }   
	}   

}
