

public class Arithmetic {
    public static void main(String[] asmd) {
        int n1=Integer.parseInt(asmd[0]);
        int n2=Integer.parseInt(asmd[1]);

        System.out.println("1st number ="+n1);
        System.out.println("2nd number ="+n2);
        System.out.println("Addition of two numbers ="+(n1 + n2));
        System.out.println("Subtraction of two numbers ="+ (n1 - n2));
        System.out.println("Multiplication of two numbers =" + (n1 * n2));
        System.out.println("Division of two numbers =" + (n1 / n2));
    }
}
