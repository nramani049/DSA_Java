public class Table 
{
	public static void main(String[] patt) 
	{
		// Prompt the user to enter a value
		int val1 = Integer.parseInt(patt[0]);
		int val2 = Integer.parseInt(patt[1]);
		
		// Print the multiplication table pattern
		for (int i = 1; i <= 10; i++) 
		{
			System.out.println(val1 + " * " + i + " = " + (val1*i)+"     "+ val2 + " * " + i + " = " + (val2*i));
		}
	}
}
