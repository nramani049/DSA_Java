Class bcaa
{
	public static void main(String n[])
	{
		System.out.println("Welcome,Nirbhay");
	}
}