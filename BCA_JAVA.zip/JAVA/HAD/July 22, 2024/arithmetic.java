// To take input from user 

import java.io.*;
import java.util.*;

class arithmetic {

    public static void main(String args[])
	{
		int n1,n2,n3;
        Scanner sc= new Scanner(System.in);
				
        System.out.println("Enter number 1 :");
		n1 = sc.nextInt();
		
        System.out.println("Enter number 2 :");
		n2 = sc.nextInt();
		
        System.out.println("Add :" + (n1+n2));
        System.out.println("Sub :" + (n1-n2));
        System.out.println("Mul :" + (n1*n2));
        System.out.println("Div :" + (n1/n2));
        
	}
    
}
