// To take input from user 

import java.io.*;
import java.util.*;

class alldt {
	public static void main(String args[])
	{
		String nm;
		int r;
        float per;
        Scanner sm= new Scanner(System.in);
		
		System.out.println("Enter Name :");
		nm = sm.nextLine();
		
        System.out.println("Enter rollno :");
		r = sm.nextInt();
		
        System.out.println("Enter per :");
		per = sm.nextFloat();
		
        System.out.println("Name :" + nm);
        System.out.println("Rollno :" + r);
        System.out.println("Per :" + per);

	}
}