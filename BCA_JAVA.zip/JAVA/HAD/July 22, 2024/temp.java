// To take input from user 

import java.io.*;
import java.util.*;

class temp
{
	public static void main(String args[])
	{
		String nm;
		Scanner s= new Scanner (System.in);
		
		System.out.println("Enter Name :");
		
		nm = s.nextLine();
		System.out.println("Name :" + nm);
	}
}