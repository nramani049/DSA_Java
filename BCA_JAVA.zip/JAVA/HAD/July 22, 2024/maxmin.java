// To take input from user 

import java.io.*;
import java.util.*;

class  maxmin {

    public static void main(String args[])
	{
		int n1,n2;
        Scanner sc= new Scanner(System.in);
				
        System.out.println("Enter number 1 :");
		n1 = sc.nextInt();
		
        System.out.println("Enter number 2 :");
		n2 = sc.nextInt();
		
        if(n1<n2)
        {
            if(n1<n3){
                System.out.println("Minimum number is : " + n1);
            }else
            {
                System.out.println("Minimum number is : " + n3);
            }
        }else
        {
            if(n2<n3){
                
            }
        }
	}
    
}
