// To take input from user 

import java.io.*;
import java.util.*;

class  oddeven {

    public static void main(String args[])
	{
		int n1;
        Scanner sc= new Scanner(System.in);
				
        System.out.println("Enter number 1 :");
		n1 = sc.nextInt();
				
        if(n1%2==0)
	{    
	        System.out.println("Odd");
        }
        else
        {
                System.out.println("Even");
	}
                
        
	}
    
}
