// To take input from user 

import java.io.*;
import java.util.*;

class  maxmin {

    public static void main(String args[])
	{
		int n1;
        Scanner sc= new Scanner(System.in);
				
        System.out.println("Enter number 1 :");
		n1 = sc.nextInt();
				
        if(n1%4==0)
	{    
	        System.out.println("Leap");
        }
        else
        {
                System.out.println("Not Leap");
	}
                
        
	}
    
}
